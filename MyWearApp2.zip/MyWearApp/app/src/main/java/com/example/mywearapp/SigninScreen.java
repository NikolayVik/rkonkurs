package com.example.mywearapp;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

import com.example.mywearapp.databinding.ActivitySigninScreenBinding;

public class SigninScreen extends Activity {

    private TextView mTextView;
    private ActivitySigninScreenBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivitySigninScreenBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        mTextView = binding.text;
    }
}