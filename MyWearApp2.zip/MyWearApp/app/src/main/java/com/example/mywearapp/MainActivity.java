package com.example.mywearapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.example.mywearapp.databinding.ActivityMainBinding;

public class MainActivity extends Activity {
    private static int SPLASH_SCREEN = 3000;
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        getWindow().setContentView(binding.getRoot());
         new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(MainActivity.this, SigninScreen.class);
                startActivity(intent);
                finish();
            }
        },SPLASH_SCREEN);
    }
}